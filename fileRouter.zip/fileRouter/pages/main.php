<a href="page_1">page_1</a>
<a href="page_2">page_2</a>
<a href="img">img</a>