<?php 

if(isset($_GET["id"]) and !empty($_GET["id"])){
  $id = $_GET["id"];
  $sql = "SELECT * FROM myblog WHERE id = :id";
      $stmt = $database->prepare($sql);
      $stmt->bindParam(":id", $id);
      $stmt->execute();
      $cont = $stmt->fetch();

      if($cont){
          if($_SERVER['REQUEST_METHOD'] === 'POST'){
              $sql = 'DELETE FROM myblog WHERE id=:id';
              $stmt = $database->prepare($sql);
              $stmt->bindParam(":id", $id);
              $stmt->execute();

              header('Location:index.php');
          }
      }else{
          die('Продукт для удаления не найден');
      }
  }else{
      die("id некорректен");
  }
?>


<main class="container">
  <h1><?= $cont["title"]?></h1>
  <p class="mb-4">
  <?= $cont["content"]?>
  </p>

  <div class="flex mb-4">
    <a href="?page=edit&id=<?= $cont["id"]?>" class="btn">Редактировать</a>
    <form method="post">
    <button
            class="btn btn-danger"
            onclick="return confirm('Вы действительно хотите удалить пост?');">
      Удалить
    </button>
    </form>
  </div>

  <a href="/" class="btn">Вернуться на главную</a>
</main>
