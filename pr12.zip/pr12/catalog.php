<?php 
  $sql = "SELECT * FROM myblog";
  $stmt = $database->prepare($sql);
  $stmt->execute();

  $contents = $stmt->fetchAll();
?>

<!-- Основной контент -->
<main class="container">
  <h1>Список постов</h1>
  <div class="post-list">
    <!-- Карточка поста -->
     <?php foreach($contents as $content): ?>
    <div class="post-card">
      <img src="<?= $content['image']?>" alt="">
      <h2><?= $content["title"]?></h2>
      <p class="post-body"><?= $content["content"]?></p>
      <div class="mt-auto">
        <a href="?page=show&id=<?= $content["id"]?>" class="btn">Читать далее</a>
      </div>
    </div>
    <?php endforeach;?>
  </div>
</main>

<style>
  img{
    width: 75px;
    height: 75px;
  }
</style>


