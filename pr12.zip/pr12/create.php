<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = $_POST['title'];
  $content = $_POST['content'];

  if (empty($title) or empty($content)) {
    echo 'Заполните все поля';
  } elseif (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $tmpName = $_FILES['image']['tmp_name'];
    $name = basename($_FILES['image']['name']);
    $extension = pathinfo($name, PATHINFO_EXTENSION);
    $newName = uniqid() . '.' . $extension;
    $newDirection = "uploads/" . $newName;

    if (move_uploaded_file($tmpName, $newDirection)) {
      $sql = "INSERT INTO myblog (title, content, image) VALUES (:title, :content, :image)";
      $stmt = $database->prepare($sql);
      $stmt->bindParam(":title", $title);
      $stmt->bindParam(":content", $content);
      $stmt->bindParam(":image", $newDirection);

      if ($stmt->execute()) {
        header('Location: index.php');
      } else {
        die('Ошибка запроса');
      }
    } else {
      echo "Ошибка загрузки изображения";
    }
  } else {
    echo "нету изображения";
  }
}
?>

<main class="container">
  <h1>Создать новый пост</h1>

  <form action="#" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="post_title">Заголовок</label>
      <input
        type="text"
        id="post_title"
        name="title"
        class="form-control"
        placeholder="Введите заголовок" />
    </div>

    <div class="form-group">
      <label for="post_content">Описание</label>
      <textarea
        id="post_content"
        name="content"
        class="form-control"
        rows="6"
        placeholder="Напишите пост..."></textarea>
    </div>
    <input type="file" name="image">
    <button type="submit" class="btn">Опубликовать</button>
  </form>
</main>