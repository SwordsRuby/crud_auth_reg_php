<?php
include('database/connection.php');
include('head.php');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <title>Главная — Блог</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
<!-- Шапка -->
<header class="header">
  <div class="header-nav container">
    <div class="logo">MyBlog</div>
    <ul class="nav-list">
      <li><a href="/">Главная</a></li>
      <?php if(isset($_SESSION['user_id'])): ?>
        <li><a href="?page=create">Создать пост</a></li>
        <li><a href="?exit">Выйти</a></li>
      <?php else: ?>
        <li><a href="?page=registration">Регистрация</a></li>
        <li><a href="?page=login">Авторизация</a></li>
      <?php endif; ?>
    </ul>
  </div>
</header>
 
<?php
if(isset($_GET['page'])){
  $page = $_GET['page'];

  if($page ==='show'){
    include('show.php');
  }elseif($page === 'edit'){
    include('edit.php');
  }elseif($page === 'create'){
    include('create.php');
  }elseif($page === 'registration'){
    include('registration.php');
  }elseif($page === 'login'){
    include('login.php');
  }else{
    include('404.php');
  }
}else{
  include('catalog.php');
}
?>

<!-- Футер -->
<footer class="footer">
  <p>&copy; 2025 MyBlog. Все права защищены.</p>
</footer>
</body>
</html>