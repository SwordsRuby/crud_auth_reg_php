<?php 
    $flag = true;

    if($_SERVER['REQUEST_METHOD'] === "POST"){
        $username = $_POST["username"];
        $surname = $_POST["surname"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $password_confirm = $_POST["password_confirm"];
    }
?>

<h1>Регистрация</h1>

<form action="" method="post">
    <input type="text" name="username" placeholder="имя" value="<?=isset($_POST['username']) ? $_POST['username'] : ''?>"><br>

    <?php 
        if(isset($_POST['username'])){
            if(empty($username)){
                $flag = false;
                echo 'поля имя пустое';
            }
        }
    ?><br>

    <input type="text" name="surname" placeholder="фамилия" value="<?=isset($_POST['surname']) ? $_POST['surname'] : ''?>"><br>

    <?php 
        if(isset($_POST['surname'])){
            if(empty($surname)){
                $flag = false;
                echo 'поля фамилия пустое';
            }
        }
    ?><br>

    <input type="email" name="email" placeholder="email" value="<?=isset($_POST['email']) ? $_POST['email'] : ''?>"><br>

    <?php 
        if(isset($_POST['email'])){
            if(empty($email)){
                $flag = false;
                echo 'поля email пустое';
            }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                $flag = false;
                echo 'email невалиден';
            }else{
                $sql = "SELECT * FROM users WHERE email = '$email'";
                $result = $database->query($sql)->fetch();
                if($result){
                    echo"пользователь существует";
                    $flag = false;
                }
            }
        }
    ?><br>

    <input type="password" name="password" placeholder="пароль"><br>
    <?php 
    if(isset($_POST["password"])){
        if(empty($password)){
            $flag = false;
            echo "поле пароль пустое";
        }elseif(strlen($password) < 6){
            $flag = false;
            echo "введите больше 6 символов";
        }
    }
    ?><br>

<input type="password" name="password_confitm" placeholder="повторите пароль"><br>
    <?php 
    if(isset($_POST["password_confirm"])){
        if(empty($password)){
            $flag = false;
            echo "поле повторите пароль пустое";
        }elseif($password_confirm != $password){
            $flag = false;
            echo "пароли не совпадают";
        }
    }
    ?><br>

    <input type="submit" value="Регистрация">
    <?php 
        if($_SERVER['REQUEST_METHOD'] === "POST"){
            if($flag){
                $password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO users (username, surname, email, password) VALUES ('$username', '$surname', '$email', '$password')";
                $result = $database->query($sql);
                header("Location: /");
            }
        }
    ?>
</form>
