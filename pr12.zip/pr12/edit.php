<?php

if (isset($_GET['id']) and !empty($_GET['id'])) {
  $id = $_GET['id'];

  $sql = 'SELECT * FROM myblog WHERE id = :id';
  $stmt = $database->prepare($sql);
  $stmt->bindParam(':id', $id);
  $stmt->execute();

  $cont = $stmt->fetch();

  if (!$cont) {
    die('Продукта не существует');
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];

    if (empty($title) or empty($content)) {
      echo 'Пустые поля';
    } elseif (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
      $tmpName = $_FILES['image']['tmp_name'];
      $name = basename($_FILES['image']['name']);
      $extension = pathinfo($name, PATHINFO_EXTENSION);
      $newName = uniqid() . '.' . $extension;
      $newDirection = 'uploads/' . $newName;
      if (move_uploaded_file($tmpName, $newDirection)) {
        unlink($cont['image']);
        $sql = 'UPDATE myblog SET title = :title, content = :content, image = :image WHERE id = :id';
        $stmt = $database->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':content', $content);
        $stmt->bindParam(':image', $newDirection);

        if ($stmt->execute()) {
          header('Location: index.php');
        } else {
          die('Ошибка запроса');
        }
      } else {
        echo 'Ошибка загрузки изображения';
      }
    } else {
      echo "Изображение не загружено";
    }
  }
}
?>

<main class="container">
  <h1>Редактировать пост</h1>

  <form action="#" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="post_title">Заголовок</label>
      <input
        type="text"
        id="post_title"
        name="title"
        class="form-control"
        value="<?= $cont["title"] ?>" />
    </div>

    <div class="form-group">
      <label for="post_content">Содержание</label>
      <textarea
        id="post_content"
        name="content"
        class="form-control"
        rows="6"><?= $cont["content"] ?></textarea>
    </div>

    <input type="file" name="image">
    <img src="<?= $cont['image'] ?>" alt="">

    <button type="submit" class="btn">Сохранить изменения</button>
  </form>
</main>

<style>
  img{
    width: 100px;
    height: 100px;
  }
</style>