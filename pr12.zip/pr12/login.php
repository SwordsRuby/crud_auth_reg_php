<?php 
    if(isset($_SESSION['user_id'])){
        include('404.php');
        return;
    }
    if($_SERVER['REQUEST_METHOD'] === "POST"){
        $email = $_POST['email'];
        $password = $_POST['password'];
    }
?>

<h1>Авторизация</h1>

<form method="post">
<input type="email" name="email" placeholder="email"><br>

<?php 
    if(isset($_POST['email'])){
        if(empty($email)){
            $flag = false;
            echo 'поля email пустое';
        }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $flag = false;
            echo 'email невалиден';
        }
    }
?><br>

<input type="password" name="password" placeholder="пароль">
<?php
    if(isset($_POST['password'])){
        if(empty($password)){
            $flag = false;
            echo 'поле пароль пустое';
        }else{
            $sql = "SELECT * FROM users WHERE email = '$email'";
            $result = $database->query($sql)->fetch();
            if(!$result){
                $flag = false;
                echo "пользователь не существует";
            }else{
                if(password_verify($password, $result["password"])){
                    $_SESSION['user_id'] = $result['id'];
                    header('Location: /');
                }else{
                    $flag = false;
                    echo 'пароль неверный';
                }
            }
        }
    }
?><br><br>

<input type="submit" value="Войти">
</form>